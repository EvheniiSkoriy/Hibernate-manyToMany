create procedure StudentsCounts(OUT cnt int)
  BEGIN
      SELECT count(*) into cnt from Students;
    end;

